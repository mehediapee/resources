# This is simple program to show how print statement works

print('Hello Python World')
