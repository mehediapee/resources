# Plagarism checker

<!--Remove the below lines and add yours -->

Python script for checking the amount of similarity between two (or more) text files.

### Prerequisites

<!--Remove the below lines and add yours -->

Sklearn module
Installation:

```
$ pip install -U scikit-learn
```

### How to run the script

<!--Remove the below lines and add yours -->

```
$ python plag.py
```

### Screenshot/GIF showing the sample use of the script

<!--Remove the below lines and add yours -->

# <img alt="PLAG" src="https://i.imgur.com/yDka1b4.png">

## _Author Name_

<!--Remove the below lines and add yours -->

Darahaas Yajamanyam <br />
[darahaas15](https://github.com/darahaas15)
