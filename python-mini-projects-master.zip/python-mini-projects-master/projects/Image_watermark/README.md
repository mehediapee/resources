# Image-Watermark

## Description

This Project will take an image and add desired watermark to it.

## About this Project

This project uses PIL module and OS module to add the watermark. PIL, the Python Imaging Library, is an open source libary that enables the users to add, manipulate and save different file formats.

## Usage

Use the Script [watermark.py](https://github.com/Python-World/python-mini-projects/blob/master/projects/Image_watermark/watermark.py) . In the command line, Enter

`python3 watermark.py [image_path]`

Replace the `[image_path]` with the image you want to add watermark to.

The output will be the image with desired watermark.

## Author
[Mitesh](https://github.com/Mitesh2499)
