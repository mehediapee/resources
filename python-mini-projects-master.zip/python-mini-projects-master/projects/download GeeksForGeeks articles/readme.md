# Download GeeksForGeeks Articles as pdf
<!--Remove the below lines and add yours -->
This script take a link of GeeksForGeeks article as input and download the complete article as a pdf at default download location.

### Prerequisites
<!--Remove the below lines and add yours -->
* selenium
* requests
* webdriver-manager
* Run `pip install -r requirements.txt` to install required external modules.

### How to run the script
<!--Remove the below lines and add yours -->
- Execute `python3 downloader.py`
- Type in URL of article when prompted.

### Screenshot/GIF showing the sample use of the script
<!--Remove the below lines and add yours -->
![Screenshot of the Output](https://github.com/Python-World/python-mini-projects/blob/master/projects/download%20GeeksForGeeks%20articles/screenshot.jpg)

## *Author Name*
<!--Remove the below lines and add yours -->
[Shiv Thakur](https://github.com/ShivSt)
