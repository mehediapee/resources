## write script to compress folder and files

### usage

python zipfiles.py file_name(or folder name)

example:
    python zipfiles.py test.txt
    python zipfiles.py ./test (folder)

A Compressed file("filename.zip") will be generated after the program is run
