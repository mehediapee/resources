## create a simple stopwatch

### usage

python stopwatch.py
