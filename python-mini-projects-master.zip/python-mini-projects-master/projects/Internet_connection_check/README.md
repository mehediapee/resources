# Internet Connection Check
<!--Remove the below lines and add yours -->
A small python script to check internet connectivity.

### Prerequisites
<!--Remove the below lines and add yours -->
Python3

### How to run the script
<!--Remove the below lines and add yours -->
> python3 internet_connection_check.py

### Screenshot/GIF showing the sample use of the script
<!--Remove the below lines and add yours -->
![output](https://github.com/AshuSharma7/python-mini-projects/raw/master/projects/Internet_connection_check/output.png)

## *Author Name*
<!--Remove the below lines and add yours -->
[Ashu Sharma](https://github.com/AshuSharma7)
[Jacob Ogle](https://github.com/JakeOgle94)
