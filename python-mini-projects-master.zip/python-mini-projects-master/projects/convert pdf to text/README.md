# PDF to TXT converter
This script takes in a .pdf file and outputs a .txt file

### Requirements
	- Python
	- PyPDF2 


### Steps
In this program you have to provide the path for the pdf file that you want to convert into text and you may also provide the path where you want your output text file to be stored.
By default the output files created will be stored in temp folder in the same directory.

## *Author Name*
[pi1814](https://github.com/pi1814)
