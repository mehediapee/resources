## WIFI PASSWORD EJECTOR
# Description
a simple python script that tells you the password of the wifi you're connected with

# Requirements
just need to install python in your system.

# How to run
run the file from your code editor or Ide or u can also run it from the command line
