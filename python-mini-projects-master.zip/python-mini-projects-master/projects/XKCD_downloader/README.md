## XKCD Downloader

### This script can be used to download any issue of the xkcd comics with just a simple command.

### How to use this script?

## 1. Install the requirements with the following line:

pip install -r requirements.txt

## 2. Run the following command from your terminal

python3 xkcd_downloader.py -l 'issue-number'

Example :

python3 xkcd_downloader.py -l 956

