
# String search from multiple files
Finds a file with the inputted string in the specified folder of your choice.

### Prerequisites
Python3 is the only prerequisites! No external modules are needed to run.

### How to run the script
In order to run this script you must have Python3 installed, not Python2. The command to run this is simply `python3 findstring.py`, and you'll be prompted with two questions, the string to search, and where to look.

### Screenshot/GIF showing the sample use of the script
![GIF showing how to run](https://i.imgur.com/2y7HdGV.gif)

## *Author Name*
[Mitesh](https://github.com/Mitesh2499)
