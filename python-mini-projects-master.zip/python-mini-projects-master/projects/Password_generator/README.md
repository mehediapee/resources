# Password_generator
This script generate a random password
## Prerequisites
None
## How to run the script
Execute : password_generator.py
## Screenshot/GIF showing the sample use of the script
![](screenshot.png)
## Author Name
lilo550